print "welcome to my Quiz game!"
def greeting():
    """welcomes you and have a function in which you are asked to choose a level"""
    begin = raw_input("would you like to play my game?")
    if begin == 'yes':
        name = raw_input("Enter your name:")
        print "Hello"+" "+name+"! " +"Happy to see you here :)"
        set_level()
    else:
        print "Thanks for trying my game.Goodluck!"
#set up of the game.
easy_paragraph = "The HTML document itself begins with _1_ and ends with _2_. HTML _3_ are defined with the <p> tag. HTML _4_ are defined with the <img> tag."#test your knowledge in HTML
medium_paragraph = "CSS is a language that describes the _1_ of an HTML document.A CSS rule-set consists of a _2_ and a declaration block. The selector points to the _3_ element you want to style.The class selector selects elements with a specific _4_ attribute."#test your knowledge in CSS
hard_paragraph = "Python is _1_ oriented programming language. In Python the identation is very _2_. In Python a _3_ is defined using the def keyword.Information can be passed to functions as _4_."#test your knowledge in Python
easy_solution = ["<html>", "</html>", "paragraphs", "images"]
medium_solution = ["style", "selector", "html", "class"]
hard_solution = ["object", "important", "function","parameter"]
blanks = ["_1_", "_2_", "_3_", "_4_"]
def set_level():
    """choose level so that we can start game according to your level"""
    level = raw_input("Choose your level among easy, medium or hard").lower()
    print "You have 4 attempts per question"
    if level == "easy":
        print "you chose level easy"
        main(easy_paragraph, blanks, easy_solution)
    elif level == "medium":
        print "you chose level medium"
        main(medium_paragraph, blanks, medium_solution)
    elif level == "hard":
        print "you chose level hard"
        main(hard_paragraph, blanks, hard_solution)
    else:
        print "sorry! Invalid input."
    print set_level
#starts the quiz
def main(quiz, blank, answer):
    """take three parameters and print quiz according to your
       level maximum attempt per question is 4 take input a word as
       your answer and return try again if wrong or return to next question
       if right"""
    print quiz
    for count_blank in range(0, len(blank)):
        answer_input = raw_input("what is solution for" + blank[count_blank]+"?")
        attempts = 1
        max_attempt = 4
        while answer_input.lower()!= answer[count_blank]:
            attempts += 1
            answer_input = raw_input("oops! Try again! what is solution for" + blank[count_blank]+"?")
            if attempts== max_attempt:
                print ("Sorry you lose the game:( Try again")
                set_level()
        else:
             print ("Correct! The solution for " +blank[count_blank] +"is" + answer_input)
             quiz = quiz.replace(blank[count_blank], answer[count_blank])
             print quiz
    if len(blank) == len(answer):
        print ("you won the game ! want to try another level!")
        set_level()
greeting()       

            
        
    
